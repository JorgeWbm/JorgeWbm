public class Questao04 {
    public static void main (String [] args){
        System.out.println("Hello World!");
    }
}